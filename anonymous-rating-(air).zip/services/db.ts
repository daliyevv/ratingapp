
import { ImageModel, AccessCode, Vote, Room } from '../types';

const STORAGE_KEYS = {
  ROOMS: 'air_rooms',
  IMAGES: 'air_images',
  CODES: 'air_codes',
  VOTES: 'air_votes',
  ADMIN_PASS: 'air_admin_pass'
};

const DEFAULT_ROOMS: Room[] = [
  { id: 'room-1', name: 'Art Showcase 2025', code: '112233', maxUploadsPerUser: 10, createdAt: Date.now() }
];

const DEFAULT_IMAGES: ImageModel[] = [
  { id: '1', title: 'Example Artwork', url: 'https://picsum.photos/seed/art/800/600', type: 'image', roomId: 'room-1', creatorId: 'admin', createdAt: Date.now() },
];

const DEFAULT_CODES: AccessCode[] = [
  { code: '112233', isActive: true, singleUse: false, usedCount: 0, roomId: 'room-1', createdAt: Date.now() },
];

const DEFAULT_ADMIN_PASS = 'admin2026';

export const DB = {
  getRooms: (): Room[] => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ROOMS);
      return data ? JSON.parse(data) : DEFAULT_ROOMS;
    } catch { return DEFAULT_ROOMS; }
  },
  saveRooms: (rooms: Room[]) => {
    localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify(rooms));
  },
  getImages: (): ImageModel[] => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.IMAGES);
      return data ? JSON.parse(data) : DEFAULT_IMAGES;
    } catch { return DEFAULT_IMAGES; }
  },
  saveImages: (images: ImageModel[]) => {
    localStorage.setItem(STORAGE_KEYS.IMAGES, JSON.stringify(images));
  },
  getCodes: (): AccessCode[] => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CODES);
      return data ? JSON.parse(data) : DEFAULT_CODES;
    } catch { return DEFAULT_CODES; }
  },
  saveCodes: (codes: AccessCode[]) => {
    localStorage.setItem(STORAGE_KEYS.CODES, JSON.stringify(codes));
  },
  getVotes: (): Vote[] => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.VOTES);
      return data ? JSON.parse(data) : [];
    } catch { return []; }
  },
  saveVotes: (votes: Vote[]) => {
    localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify(votes));
  },
  getAdminPass: (): string => {
    return localStorage.getItem(STORAGE_KEYS.ADMIN_PASS) || DEFAULT_ADMIN_PASS;
  },
  setAdminPass: (pass: string) => {
    localStorage.setItem(STORAGE_KEYS.ADMIN_PASS, pass);
  }
};

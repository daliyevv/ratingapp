
import { DB } from './db';
import { ImageModel, AccessCode, Vote, ImageStats, Room, AssetType } from '../types';

export const API = {
  // Authentication
  login: async (code: string): Promise<{ success: boolean; message: string; anonId?: string; roomId?: string; roomName?: string }> => {
    const codes = DB.getCodes();
    const rooms = DB.getRooms();
    const foundCode = codes.find(c => c.code === code);

    if (!foundCode || !foundCode.isActive) {
      return { success: false, message: 'Kod noto\'g\'ri yoki faol emas' };
    }

    if (foundCode.singleUse && foundCode.usedCount > 0) {
      return { success: false, message: 'Bu bir martalik kod allaqachon ishlatilgan' };
    }

    const room = rooms.find(r => r.id === foundCode.roomId);
    if (!room) return { success: false, message: 'Xona topilmadi' };

    const updatedCodes = codes.map(c => 
      c.code === code ? { ...c, usedCount: c.usedCount + 1 } : c
    );
    DB.saveCodes(updatedCodes);

    return { 
      success: true, 
      message: 'Muvaffaqiyatli kirildi', 
      anonId: Math.random().toString(36).substr(2, 9),
      roomId: room.id,
      roomName: room.name
    };
  },

  adminLogin: async (password: string): Promise<{ success: boolean; message: string }> => {
    const currentPass = DB.getAdminPass();
    if (password === currentPass) {
      return { success: true, message: 'Admin sifatida kirildi' };
    }
    return { success: false, message: 'Admin paroli noto\'g\'ri' };
  },

  updateAdminPassword: (newPass: string) => {
    if (newPass.length < 4) return false;
    DB.setAdminPass(newPass);
    return true;
  },

  getRooms: async (): Promise<Room[]> => {
    return DB.getRooms();
  },

  createRoom: (name: string, code: string, maxUploads: number = 5) => {
    const rooms = DB.getRooms();
    const codes = DB.getCodes();
    if (rooms.find(r => r.code === code) || codes.find(c => c.code === code)) return null;

    const newRoom: Room = {
      id: 'room-' + Math.random().toString(36).substr(2, 9),
      name,
      code,
      maxUploadsPerUser: maxUploads,
      createdAt: Date.now()
    };

    const newCode: AccessCode = {
      code,
      isActive: true,
      singleUse: false,
      usedCount: 0,
      roomId: newRoom.id,
      createdAt: Date.now()
    };

    DB.saveRooms([...rooms, newRoom]);
    DB.saveCodes([...codes, newCode]);
    return newRoom;
  },

  deleteRoom: (id: string) => {
    const rooms = DB.getRooms().filter(r => r.id !== id);
    const codes = DB.getCodes().filter(c => c.roomId !== id);
    const images = DB.getImages().filter(img => img.roomId !== id);
    DB.saveRooms(rooms);
    DB.saveCodes(codes);
    DB.saveImages(images);
  },

  getImages: async (roomId?: string): Promise<ImageModel[]> => {
    const all = DB.getImages();
    if (roomId) return all.filter(img => img.roomId === roomId);
    return all;
  },

  getImageById: async (id: string): Promise<ImageModel | undefined> => {
    return DB.getImages().find(img => img.id === id);
  },

  addImage: (title: string, url: string, type: AssetType, roomId: string, creatorId: string = 'admin') => {
    const rooms = DB.getRooms();
    const room = rooms.find(r => r.id === roomId);
    
    if (room && creatorId !== 'admin') {
      const userImages = DB.getImages().filter(img => img.roomId === roomId && img.creatorId === creatorId);
      if (userImages.length >= room.maxUploadsPerUser) {
        throw new Error(`Limitga yetdingiz.`);
      }
    }

    const images = DB.getImages();
    const newImage: ImageModel = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      url,
      type,
      roomId,
      creatorId,
      createdAt: Date.now()
    };
    DB.saveImages([...images, newImage]);
    return newImage;
  },

  deleteImage: (id: string) => {
    const images = DB.getImages().filter(img => img.id !== id);
    const votes = DB.getVotes().filter(v => v.imageId !== id);
    DB.saveImages(images);
    DB.saveVotes(votes);
  },

  getStats: (imageId: string): ImageStats => {
    const votes = DB.getVotes().filter(v => v.imageId === imageId);
    if (votes.length === 0) return { average: 0, count: 0, min: 0, max: 0 };
    const sum = votes.reduce((acc, v) => acc + v.score, 0);
    const scores = votes.map(v => v.score);
    return {
      average: Math.round((sum / votes.length) * 10) / 10,
      count: votes.length,
      min: Math.min(...scores),
      max: Math.max(...scores)
    };
  },

  submitVote: async (imageId: string, anonId: string, code: string, score: number): Promise<{ success: boolean; message: string }> => {
    const votes = DB.getVotes();
    const existing = votes.find(v => v.imageId === imageId && v.anonId === anonId);
    if (existing) return { success: false, message: 'Siz allaqachon ovoz bergansiz' };

    const newVote: Vote = {
      id: Math.random().toString(36).substr(2, 9),
      imageId,
      anonId,
      codeUsed: code,
      score,
      createdAt: Date.now()
    };
    DB.saveVotes([...votes, newVote]);
    return { success: true, message: 'Ovoz qabul qilindi' };
  },

  getUserVote: (imageId: string, anonId: string): Vote | undefined => {
    return DB.getVotes().find(v => v.imageId === imageId && v.anonId === anonId);
  },

  getCodes: (): AccessCode[] => {
    return DB.getCodes();
  },

  createCode: (code: string, singleUse: boolean, roomId: string) => {
    const codes = DB.getCodes();
    if (codes.find(c => c.code === code)) return false;
    const newCode: AccessCode = { code, isActive: true, singleUse, usedCount: 0, roomId, createdAt: Date.now() };
    DB.saveCodes([...codes, newCode]);
    return true;
  },

  deleteCode: (code: string) => {
    const codes = DB.getCodes().filter(c => c.code !== code);
    DB.saveCodes(codes);
  }
};

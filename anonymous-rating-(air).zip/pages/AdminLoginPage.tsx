
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { API } from '../services/api';
import { AuthState } from '../types';

interface AdminLoginPageProps {
  setAuth: (auth: AuthState) => void;
}

const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ setAuth }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const res = await API.adminLogin(password);
    setLoading(false);

    if (res.success) {
      // Fixed: Added missing roomId and roomName properties to satisfy AuthState interface
      setAuth({ 
        isLoggedIn: true, 
        anonId: 'admin_session', 
        code: 'ADMIN', 
        isAdmin: true,
        roomId: null,
        roomName: null
      });
      navigate('/admin');
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="flex-grow flex items-center justify-center p-6 bg-slate-900">
      <div className="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 text-purple-600 rounded-full mb-4 text-3xl">
            🔐
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Admin Kirish</h1>
          <p className="text-gray-500 mt-2">Boshqaruv paneliga kirish uchun parolni kiriting</p>
        </div>

        <form onSubmit={handleAdminLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Admin Paroli</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none transition-colors"
              autoFocus
            />
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm font-medium text-center border border-red-100">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !password}
            className="w-full bg-purple-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-purple-700 disabled:opacity-50 shadow-lg active:transform active:scale-95 transition-all"
          >
            {loading ? 'Kirilmoqda...' : 'Admin Panelga Kirish'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => navigate('/')}
            className="text-sm text-gray-400 hover:text-purple-600 font-medium"
          >
            ← Foydalanuvchi qismiga qaytish
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminLoginPage;

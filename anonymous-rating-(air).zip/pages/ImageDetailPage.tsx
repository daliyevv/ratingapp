
import React, { useEffect, useState, Suspense, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Canvas, useLoader } from '@react-three/fiber';
import { OrbitControls, Stage, Center } from '@react-three/drei';
import * as THREE from 'three';
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader';
import { API } from '../services/api';
import { ImageModel, ImageStats, AuthState, Vote } from '../types';

const STLModel = ({ url }: { url: string }) => {
  const geometry = useLoader(STLLoader, url);
  return (
    <mesh geometry={geometry}>
      <meshStandardMaterial color="#3b82f6" roughness={0.3} metalness={0.8} />
    </mesh>
  );
};

interface ImageDetailPageProps {
  auth: AuthState;
}

const ImageDetailPage: React.FC<ImageDetailPageProps> = ({ auth }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [image, setImage] = useState<ImageModel | null>(null);
  const [stats, setStats] = useState<ImageStats | null>(null);
  const [score, setScore] = useState<number>(50);
  const [userVote, setUserVote] = useState<Vote | undefined>(undefined);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (id) {
        setLoading(true);
        const img = await API.getImageById(id);
        if (img) {
          setImage(img);
          setStats(API.getStats(id));
          setUserVote(API.getUserVote(id, auth.anonId!));
        } else {
          navigate('/gallery');
        }
        setLoading(false);
      }
    };
    loadData();
  }, [id, auth.anonId, navigate]);

  const handleSubmit = async () => {
    if (!id || !auth.anonId || !auth.code) return;
    const res = await API.submitVote(id, auth.anonId, auth.code, score);
    if (res.success) {
      setMessage({ type: 'success', text: res.message });
      setStats(API.getStats(id));
      setUserVote(API.getUserVote(id, auth.anonId));
    } else {
      setMessage({ type: 'error', text: res.message });
    }
  };

  if (loading) return <div className="flex-grow flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;
  if (!image || !stats) return null;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 w-full">
      <button onClick={() => navigate('/gallery')} className="mb-6 flex items-center text-gray-500 hover:text-blue-600 font-medium">← Qaytish</button>
      
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100 flex flex-col lg:flex-row">
        <div className="lg:w-3/5 bg-gray-900 h-[400px] lg:h-auto min-h-[400px] relative">
          {image.type === 'image' ? (
            <img src={image.url} alt={image.title} className="w-full h-full object-contain bg-gray-100" />
          ) : (
            <>
              <div className="absolute top-4 left-4 z-10 bg-white/10 backdrop-blur-md border border-white/20 text-white text-[10px] px-3 py-1 rounded-full font-bold">
                Aylantirish uchun sichqonchadan foydalaning
              </div>
              <Canvas shadows camera={{ position: [0, 0, 150], fov: 45 }}>
                <Suspense fallback={null}>
                  <Stage environment="city" intensity={0.5} contactShadow={{ opacity: 0.7, blur: 2 }}>
                    <Center>
                      <STLModel url={image.url} />
                    </Center>
                  </Stage>
                </Suspense>
                <OrbitControls autoRotate autoRotateSpeed={0.5} makeDefault />
              </Canvas>
            </>
          )}
        </div>

        <div className="lg:w-2/5 p-8 flex flex-col justify-between border-l border-gray-50">
          <div>
            <h1 className="text-3xl font-black text-gray-900 mb-4">{image.title}</h1>
            
            <div className="grid grid-cols-2 gap-3 mb-8">
              <div className="bg-blue-50 p-4 rounded-2xl">
                <div className="text-[10px] text-blue-500 font-black uppercase">O'rtacha ball</div>
                <div className="text-3xl font-black text-blue-700">{stats.average}</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-2xl">
                <div className="text-[10px] text-gray-400 font-black uppercase">Ovozlar</div>
                <div className="text-3xl font-black text-gray-700">{stats.count}</div>
              </div>
            </div>

            {userVote ? (
              <div className="bg-green-50 border-2 border-green-100 p-6 rounded-2xl text-center">
                <div className="text-3xl mb-2">✨</div>
                <h3 className="text-green-800 font-bold">Baholangandi</h3>
                <p className="text-green-600">Siz <span className="font-black underline">{userVote.score}</span> ball bergansiz.</p>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center font-black text-4xl text-blue-600">{score}</div>
                <input type="range" min="1" max="100" value={score} onChange={(e) => setScore(parseInt(e.target.value))} className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600" />
                <button onClick={handleSubmit} className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-xl shadow-lg active:scale-95 transition-all">Yuborish</button>
              </div>
            )}
            {message && <div className={`mt-4 p-3 rounded-xl text-center text-sm font-bold ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{message.text}</div>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageDetailPage;

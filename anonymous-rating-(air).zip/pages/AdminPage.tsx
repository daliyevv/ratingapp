
import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import { ImageModel, AccessCode, Room, ImageStats, AssetType } from '../types';

interface RankedImage extends ImageModel {
  stats: ImageStats;
}

const AdminPage: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [images, setImages] = useState<ImageModel[]>([]);
  const [codes, setCodes] = useState<AccessCode[]>([]);
  const [activeTab, setActiveTab] = useState<'rooms' | 'images' | 'codes' | 'settings' | 'room-stats'>('rooms');

  const [statsRoom, setStatsRoom] = useState<Room | null>(null);
  const [roomRankedImages, setRoomRankedImages] = useState<RankedImage[]>([]);

  const [roomName, setRoomName] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [maxUploads, setMaxUploads] = useState(5);

  const [imgTitle, setImgTitle] = useState('');
  const [imgFile, setImgFile] = useState<File | null>(null);
  const [selectedRoomId, setSelectedRoomId] = useState('');

  const [newCode, setNewCode] = useState('');
  const [singleUse, setSingleUse] = useState(false);
  const [codeRoomId, setCodeRoomId] = useState('');

  const [newPass, setNewPass] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => { refreshData(); }, []);

  const refreshData = async () => {
    const r = await API.getRooms();
    setRooms(r);
    setImages(await API.getImages());
    setCodes(API.getCodes());
    if (r.length > 0 && !selectedRoomId) setSelectedRoomId(r[0].id);
    if (r.length > 0 && !codeRoomId) setCodeRoomId(r[0].id);
  };

  const handleAddRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomName || roomCode.length !== 6) return;
    if (API.createRoom(roomName, roomCode, maxUploads)) {
      setRoomName(''); setRoomCode(''); refreshData();
    }
  };

  const handleAddImage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imgTitle || !imgFile || !selectedRoomId) return;

    const reader = new FileReader();
    reader.onload = () => {
      const type: AssetType = imgFile.name.toLowerCase().endsWith('.stl') ? 'stl' : 'image';
      API.addImage(imgTitle, reader.result as string, type, selectedRoomId);
      setImgTitle(''); setImgFile(null); refreshData();
    };
    reader.readAsDataURL(imgFile);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 w-full">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-black text-gray-900">Admin Panel</h1>
        <div className="text-xs bg-gray-100 px-3 py-1 rounded text-gray-500 font-mono italic">Support 3D STL</div>
      </div>

      <div className="flex gap-2 mb-8 bg-white p-1 rounded-2xl shadow-sm inline-flex overflow-x-auto w-full md:w-auto">
        {['rooms', 'images', 'codes', 'settings'].map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab as any)} className={`px-6 py-3 rounded-xl font-bold capitalize whitespace-nowrap ${activeTab === tab ? 'bg-blue-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}>
            {tab}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          {activeTab === 'rooms' && (
            <div className="bg-white p-6 rounded-3xl shadow-lg border border-gray-100">
              <h2 className="text-xl font-bold mb-6">Xona Yaratish</h2>
              <form onSubmit={handleAddRoom} className="space-y-4">
                <input type="text" placeholder="Xona Nomi" value={roomName} onChange={e => setRoomName(e.target.value)} className="w-full p-3 border rounded-xl" />
                <input type="text" maxLength={6} placeholder="6 Xonali Kod" value={roomCode} onChange={e => setRoomCode(e.target.value.replace(/\D/g, ''))} className="w-full p-3 border rounded-xl font-bold" />
                <input type="number" min={1} value={maxUploads} onChange={e => setMaxUploads(parseInt(e.target.value))} className="w-full p-3 border rounded-xl" />
                <button className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold">Xonani Yaratish</button>
              </form>
            </div>
          )}

          {activeTab === 'images' && (
            <div className="bg-white p-6 rounded-3xl shadow-lg border border-gray-100">
              <h2 className="text-xl font-bold mb-6">Rasm/Model Qo'shish</h2>
              <form onSubmit={handleAddImage} className="space-y-4">
                <select value={selectedRoomId} onChange={e => setSelectedRoomId(e.target.value)} className="w-full p-3 border rounded-xl font-bold">
                  {rooms.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
                <input type="text" placeholder="Sarlavha" value={imgTitle} onChange={e => setImgTitle(e.target.value)} className="w-full p-3 border rounded-xl" required />
                <input type="file" accept="image/*,.stl" onChange={e => setImgFile(e.target.files?.[0] || null)} className="w-full p-2 border rounded-xl" required />
                <button className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold">Saqlash</button>
              </form>
            </div>
          )}
        </div>

        <div className="lg:col-span-2">
          <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b">
                <tr><th className="p-4 text-xs font-black uppercase text-gray-400">Element</th><th className="p-4 text-xs font-black uppercase text-gray-400">Ma'lumot</th><th className="p-4 text-xs font-black uppercase text-gray-400 text-center">Amallar</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {activeTab === 'rooms' && rooms.map(r => (
                  <tr key={r.id}>
                    <td className="p-4 font-bold">{r.name}</td>
                    <td className="p-4 text-xs">Kod: {r.code} | Limit: {r.maxUploadsPerUser}</td>
                    <td className="p-4 text-center">
                      <button onClick={() => { if(confirm('O\'chirilsinmi?')) { API.deleteRoom(r.id); refreshData(); } }} className="text-red-500 font-bold hover:underline">O'chirish</button>
                    </td>
                  </tr>
                ))}
                {activeTab === 'images' && images.map(img => (
                  <tr key={img.id}>
                    <td className="p-4 flex items-center gap-2">
                      <div className={`w-8 h-8 rounded flex items-center justify-center text-white font-bold text-[10px] ${img.type === 'stl' ? 'bg-purple-600' : 'bg-blue-600'}`}>{img.type === 'stl' ? '3D' : 'IMG'}</div>
                      <span className="font-bold">{img.title}</span>
                    </td>
                    <td className="p-4 text-xs">Xona: {rooms.find(r => r.id === img.roomId)?.name}</td>
                    <td className="p-4 text-center"><button onClick={() => { API.deleteImage(img.id); refreshData(); }} className="text-red-500 font-bold">O'chirish</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;

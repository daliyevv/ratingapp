
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { API } from '../services/api';
import { ImageModel, ImageStats, AuthState } from '../types';

interface RankedImage extends ImageModel {
  stats: ImageStats;
}

interface LeaderboardPageProps {
  auth: AuthState;
}

const LeaderboardPage: React.FC<LeaderboardPageProps> = ({ auth }) => {
  const [rankedImages, setRankedImages] = useState<RankedImage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAndRank = async () => {
      if (!auth.roomId) return;
      const images = await API.getImages(auth.roomId);
      const withStats = images.map(img => ({
        ...img,
        stats: API.getStats(img.id)
      }));
      
      // Strict sorting: Average descending, then count descending
      const sorted = withStats.sort((a, b) => {
        if (b.stats.average !== a.stats.average) return b.stats.average - a.stats.average;
        return b.stats.count - a.stats.count;
      });
      
      setRankedImages(sorted);
      setLoading(false);
    };
    fetchAndRank();
  }, [auth.roomId]);

  if (loading) return <div className="flex-grow flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 w-full">
      <header className="mb-10 text-center">
        <h1 className="text-4xl font-black text-gray-900 mb-3 tracking-tight">Xona Reytingi 🏆</h1>
        <p className="text-gray-500 max-w-lg mx-auto">Eng yuqori ball to'plagan ishlar ro'yxati. Ovozlar soni va o'rtacha ballga asoslangan.</p>
        <div className="mt-4 inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-1.5 rounded-full text-sm font-bold border border-blue-100">
          Xona: {auth.roomName}
        </div>
      </header>

      <div className="space-y-4">
        {rankedImages.map((img, index) => {
          const isTop3 = index < 3;
          const rankColor = index === 0 ? 'bg-yellow-400' : index === 1 ? 'bg-gray-300' : index === 2 ? 'bg-orange-300' : 'bg-white';
          const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : null;

          return (
            <Link 
              key={img.id} 
              to={`/image/${img.id}`}
              className={`flex items-center gap-4 p-4 rounded-3xl transition-all border group hover:shadow-lg ${isTop3 ? 'bg-white border-blue-100 shadow-sm scale-[1.02]' : 'bg-white/50 border-gray-100'}`}
            >
              {/* Rank Badge */}
              <div className={`flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-2xl font-black text-xl shadow-inner ${rankColor} ${index < 3 ? 'text-white' : 'text-gray-400 border border-gray-100'}`}>
                {medal || index + 1}
              </div>

              {/* Preview */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 flex-shrink-0 rounded-2xl overflow-hidden bg-gray-100 border border-gray-50">
                {img.type === 'image' ? (
                  <img src={img.url} alt={img.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-3xl">🏗️</div>
                )}
              </div>

              {/* Info */}
              <div className="flex-grow min-w-0">
                <h3 className="font-black text-gray-900 text-lg truncate leading-tight group-hover:text-blue-600 transition-colors">{img.title}</h3>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-tighter">
                    {img.stats.count} ta ovoz
                  </span>
                  <div className="h-1 w-1 rounded-full bg-gray-200"></div>
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-tighter">
                    {img.type === 'stl' ? '3D Model' : 'Rasm'}
                  </span>
                </div>
                
                {/* Score Bar */}
                <div className="mt-2 w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ${isTop3 ? 'bg-blue-500' : 'bg-gray-400'}`} 
                    style={{ width: `${img.stats.average}%` }}
                  ></div>
                </div>
              </div>

              {/* Final Score */}
              <div className="flex flex-col items-end gap-1 ml-2">
                <div className={`text-2xl font-black ${isTop3 ? 'text-blue-600' : 'text-gray-700'}`}>
                  {img.stats.average}
                </div>
                <div className="text-[10px] font-black uppercase text-gray-300 tracking-widest">Ball</div>
              </div>
            </Link>
          );
        })}

        {rankedImages.length === 0 && (
          <div className="text-center py-24 bg-white rounded-3xl border-2 border-dashed border-gray-100">
            <div className="text-6xl mb-6">🏜️</div>
            <h3 className="text-xl font-bold text-gray-900">Hali hech narsa yo'q</h3>
            <p className="text-gray-500 mt-2">Xonaga rasm yuklang va ovoz berishni boshlang!</p>
            <Link to="/gallery" className="mt-6 inline-block bg-blue-600 text-white px-8 py-3 rounded-2xl font-bold shadow-lg">Galereyaga qaytish</Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default LeaderboardPage;

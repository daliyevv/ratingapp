
import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { API } from '../services/api';
import { ImageModel, AuthState, Room, AssetType } from '../types';

interface GalleryPageProps {
  auth: AuthState;
}

type FilterType = 'all' | 'pending' | 'rated' | 'mine' | 'top';

const GalleryPage: React.FC<GalleryPageProps> = ({ auth }) => {
  const [images, setImages] = useState<ImageModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUpload, setShowUpload] = useState(false);
  const [room, setRoom] = useState<Room | null>(null);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  
  const [title, setTitle] = useState('');
  const [file, setFile] = useState<File | null>(null);

  const fetchImages = async () => {
    if (auth.roomId) {
      const data = await API.getImages(auth.roomId);
      setImages(data);
      const rooms = await API.getRooms();
      setRoom(rooms.find(r => r.id === auth.roomId) || null);
    }
    setLoading(false);
  };

  useEffect(() => { fetchImages(); }, [auth.roomId]);

  const statsMap = useMemo(() => {
    const map: Record<string, any> = {};
    images.forEach(img => {
      map[img.id] = API.getStats(img.id);
    });
    return map;
  }, [images]);

  // Foydalanuvchining shaxsiy ishlari statistikasi
  const myImages = useMemo(() => images.filter(img => img.creatorId === auth.anonId), [images, auth.anonId]);
  
  const userStats = useMemo(() => {
    if (myImages.length === 0) return { avg: 0, totalVotes: 0, count: 0 };
    let totalSum = 0;
    let totalVotes = 0;
    myImages.forEach(img => {
      const s = statsMap[img.id];
      if (s) {
        totalSum += s.average;
        totalVotes += s.count;
      }
    });
    return {
      avg: Math.round((totalSum / myImages.length) * 10) / 10,
      totalVotes,
      count: myImages.length
    };
  }, [myImages, statsMap]);

  const filteredImages = useMemo(() => {
    let result = [...images];
    if (filter === 'pending') {
      result = result.filter(img => !API.getUserVote(img.id, auth.anonId!));
    } else if (filter === 'rated') {
      result = result.filter(img => !!API.getUserVote(img.id, auth.anonId!));
    } else if (filter === 'mine') {
      result = myImages;
    } else if (filter === 'top') {
      result = result.sort((a, b) => (statsMap[b.id]?.average || 0) - (statsMap[a.id]?.average || 0));
    }
    return result;
  }, [filter, images, myImages, statsMap, auth.anonId]);

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !file || !auth.roomId || !auth.anonId) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      const type: AssetType = file.name.toLowerCase().endsWith('.stl') ? 'stl' : 'image';
      try {
        API.addImage(title, base64, type, auth.roomId!, auth.anonId!);
        setTitle(''); setFile(null); setShowUpload(false); setError('');
        fetchImages();
      } catch (err: any) { setError(err.message); }
    };
    reader.readAsDataURL(file);
  };

  if (loading) return <div className="flex-grow flex items-center justify-center min-h-[60vh]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;

  const canUpload = room ? userStats.count < room.maxUploadsPerUser : true;

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8">
      <header className="mb-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-block bg-blue-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md mb-2 uppercase tracking-widest">Live Room</div>
            <h1 className="text-4xl font-black text-slate-900 tracking-tight">{auth.roomName}</h1>
            <p className="text-slate-500 text-sm mt-1">Ijodiy ishlarni baholang va o'z asaringizni ulashing</p>
          </div>
          <button onClick={() => setShowUpload(!showUpload)} className={`px-6 py-3 rounded-2xl font-bold shadow-xl transition-all active:scale-95 ${showUpload ? 'bg-slate-200 text-slate-700' : 'bg-blue-600 text-white hover:bg-blue-700'}`}>
            {showUpload ? 'Yopish' : '+ Yangi Ish Qo\'shish'}
          </button>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-4 no-scrollbar -mx-4 px-4">
          {[
            { id: 'all', label: 'Barchasi', count: images.length },
            { id: 'pending', label: 'Kutilmoqda', count: (images.length - images.filter(img => !!API.getUserVote(img.id, auth.anonId!)).length) },
            { id: 'rated', label: 'Baholangan', count: images.filter(img => !!API.getUserVote(img.id, auth.anonId!)).length },
            { id: 'mine', label: 'Mening ishlarim', count: userStats.count },
            { id: 'top', label: 'Reyting 🏆', count: null },
          ].map((f) => (
            <button key={f.id} onClick={() => setFilter(f.id as any)} className={`px-5 py-2.5 rounded-2xl text-xs font-black whitespace-nowrap transition-all border-2 ${filter === f.id ? 'bg-slate-900 text-white border-slate-900 shadow-lg' : 'bg-white text-slate-500 border-slate-100 hover:border-slate-200'}`}>
              {f.label} {f.count !== null && <span className="ml-1 opacity-50">({f.count})</span>}
            </button>
          ))}
        </div>
      </header>

      {filter === 'mine' && userStats.count > 0 && (
        <div className="mb-10 grid grid-cols-1 sm:grid-cols-3 gap-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-3xl text-white shadow-2xl shadow-blue-200">
            <p className="text-[10px] font-black uppercase opacity-70 tracking-tighter">O'rtacha ballingiz</p>
            <div className="text-5xl font-black mt-2">{userStats.avg}</div>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-tighter">Jami ovozlar</p>
            <div className="text-4xl font-black text-slate-800 mt-2">{userStats.totalVotes}</div>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-tighter">Ishlar soni</p>
            <div className="text-4xl font-black text-slate-800 mt-2">{userStats.count} <span className="text-lg opacity-30">/ {room?.maxUploadsPerUser}</span></div>
          </div>
        </div>
      )}

      {showUpload && (
        <div className="mb-12 bg-white p-8 rounded-[2rem] shadow-2xl border border-blue-50 animate-in fade-in zoom-in-95 duration-300">
          <h2 className="text-2xl font-black mb-6 text-slate-900">Yangi asar yuklash</h2>
          {!canUpload ? (
            <div className="bg-orange-50 text-orange-700 p-5 rounded-2xl font-bold border border-orange-100 flex items-center gap-3">
              <span className="text-2xl">⚠️</span> Limitga yetdingiz. Maksimal {room?.maxUploadsPerUser} ta ish yuklash mumkin.
            </div>
          ) : (
            <form onSubmit={handleUpload} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[11px] font-black text-slate-400 uppercase ml-1">Ish sarlavhasi</label>
                  <input type="text" placeholder="Ishingizga nom bering..." value={title} onChange={e => setTitle(e.target.value)} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl outline-none transition-all font-medium" required />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-black text-slate-400 uppercase ml-1">Fayl (Rasm yoki STL)</label>
                  <input type="file" accept="image/*,.stl" onChange={e => setFile(e.target.files?.[0] || null)} className="w-full p-3 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl cursor-pointer text-sm font-medium" required />
                </div>
              </div>
              {error && <p className="text-red-500 text-sm font-bold bg-red-50 p-4 rounded-xl border border-red-100">{error}</p>}
              <button className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-lg hover:bg-blue-700 shadow-xl shadow-blue-100 active:scale-95 transition-all">Tasdiqlash va Yuklash</button>
            </form>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8">
        {filteredImages.map(img => {
          const stats = statsMap[img.id];
          const userVote = API.getUserVote(img.id, auth.anonId!);
          const isMine = img.creatorId === auth.anonId;
          
          return (
            <Link key={img.id} to={`/image/${img.id}`} className={`group flex flex-col bg-white rounded-[1.5rem] overflow-hidden border border-slate-100 transition-all hover:shadow-2xl hover:-translate-y-1 ${isMine ? 'ring-2 ring-indigo-500 ring-offset-4' : ''}`}>
              <div className="aspect-[4/3] relative overflow-hidden bg-slate-100 flex items-center justify-center">
                {img.type === 'image' ? (
                  <img src={img.url} alt={img.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                ) : (
                  <div className="text-5xl group-hover:scale-125 transition-transform">🏗️</div>
                )}
                
                <div className="absolute top-3 left-3 flex gap-1.5">
                  {img.type === 'stl' && <div className="bg-purple-600 text-white text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-tighter shadow-lg">3D Model</div>}
                  {isMine && <div className="bg-indigo-600 text-white text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-tighter shadow-lg">Mening ishim</div>}
                </div>

                {userVote ? (
                  <div className="absolute top-3 right-3 bg-emerald-500 text-white text-[10px] font-black px-2 py-1 rounded-lg shadow-xl">✓ {userVote.score}</div>
                ) : !isMine && (
                  <div className="absolute top-3 right-3 bg-orange-500 text-white text-[10px] font-black px-2 py-1 rounded-lg shadow-xl animate-pulse">Baholang</div>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-bold text-slate-800 text-sm truncate mb-3">{img.title}</h3>
                <div className="flex justify-between items-center">
                  <div className={`text-[11px] font-black px-2.5 py-1 rounded-full ${stats?.average >= 85 ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                    ⭐ {stats?.average || 0}
                  </div>
                  <div className="text-slate-400 text-[10px] font-bold uppercase tracking-tighter italic">
                    {stats?.count || 0} ovoz
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {filteredImages.length === 0 && (
        <div className="text-center py-32 bg-slate-50 rounded-[2.5rem] border-2 border-dashed border-slate-200">
          <div className="text-7xl mb-6 grayscale opacity-50">🏜️</div>
          <p className="text-slate-400 font-black text-xl">Hech narsa topilmadi</p>
          <p className="text-slate-400 text-sm mt-2">Boshqa bo'limga o'tib ko'ring yoki birinchi bo'lib rasm yuklang!</p>
        </div>
      )}
    </div>
  );
};

export default GalleryPage;

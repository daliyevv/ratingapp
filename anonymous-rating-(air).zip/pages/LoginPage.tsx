
import React, { useState } from 'react';
import { API } from '../services/api';
import { AuthState } from '../types';

interface LoginPageProps {
  setAuth: (auth: AuthState) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ setAuth }) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length !== 6) {
      setError('Kod 6 ta raqamdan iborat bo\'lishi kerak');
      return;
    }

    setLoading(true);
    setError('');

    const res = await API.login(code);
    setLoading(false);

    if (res.success && res.anonId) {
      setAuth({ 
        isLoggedIn: true, 
        anonId: res.anonId, 
        code, 
        isAdmin: false,
        roomId: res.roomId || null,
        roomName: res.roomName || null
      });
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="flex-grow flex items-center justify-center p-6 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md transform transition-all">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4 text-3xl">
            🖼️
          </div>
          <h1 className="text-2xl font-bold text-gray-900">AIR Platformasi</h1>
          <p className="text-gray-500 mt-2">Xonaga kirish uchun 6 xonali kodni kiriting</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <input
              type="text"
              inputMode="numeric"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
              placeholder="000000"
              className="w-full text-center text-4xl tracking-[0.5rem] font-bold py-4 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
              autoFocus
            />
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm font-medium text-center">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || code.length !== 6}
            className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg active:transform active:scale-95 transition-all"
          >
            {loading ? 'Xona tekshirilmoqda...' : 'Xonaga Kirish'}
          </button>
        </form>

        <p className="mt-8 text-xs text-center text-gray-400">
          Admin tomonidan berilgan koddan foydalaning.
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
